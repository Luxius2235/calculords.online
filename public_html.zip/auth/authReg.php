<?php

include 'conn.php';
$error="";

if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
};
//pag kulang ung sinubmit na data
if (!isset($_POST['firstName'], $_POST['lastName'],$_POST['email'], $_POST['pass'], $_POST['username'])) {
    echo "sldfsl,dfl,sd sdlmfdsfsdfsd";
};
//pag walang laman ang input
if (empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['email']) || empty($_POST['pass']) || empty($_POST['username'])) {
    echo "sldfsl,dfl,sd sdlmfeto";
    exit();
};

if (strlen($_POST['pass']) < 10) {
    echo "Password is too short.";
    exit();
}

if (strlen($_POST['username']) > 10) {
    echo "Username is too long";
    exit();
}

$username = $_POST['username'];
$usernameNew = preg_replace("/\s+/", "",$username);


if ($stmt = $con->prepare('SELECT id, pass FROM users WHERE username = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
	$stmt->bind_param('s', $usernameNew);
	$stmt->execute();
	$stmt->store_result();
    if ($stmt->num_rows > 0) {
		// Username already exists
        echo "Username already exist.";
        exit();
	}


}



if ($stmt = $con->prepare('SELECT id, pass FROM users WHERE email = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
	$stmt->bind_param('s', $_POST['email']);
	$stmt->execute();
	$stmt->store_result();
	// Store the result so we can check if the account exists in the database.
	if ($stmt->num_rows > 0) {
		// Username already exists
        echo "Error'>Email already exist";
        exit();



	} else {

        $role = 'user';
        $prof = 'gauss.jpg';
        
		if ($stmt = $con ->prepare('INSERT INTO users (first, last, email, pass, username, role, prof) VALUES (?, ?, ?, ?, ?, ?, ?)')){
            $pass = password_hash($_POST['pass'], PASSWORD_DEFAULT);
            $stmt -> bind_param ('sssssss', $_POST['firstName'], $_POST['lastName'], $_POST['email'],$pass, $usernameNew, $role, $prof);
            $stmt -> execute();

            echo "<span style='color:skyblue'>Registration Success. Please log in.";
            echo "<script>$('.register')[0].reset(); </script>";

            


        }

        else{

        }
    
    }
    
    
        $stmt -> close();    
    }
        else {
            echo "Register Failed.";
        }   
                $con -> close();
                ?>
