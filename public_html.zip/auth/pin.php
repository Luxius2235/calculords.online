<?php
session_start();
include'conn.php';

$commid = $_POST['commid'];

$sql = "SELECT * FROM pins WHERE commid = '$commid'";
$result = mysqli_query($con, $sql);
if(mysqli_num_rows($result)>0){
    exit();
}else{

$sql = "INSERT INTO pins (commid) VALUES ('$commid')";
mysqli_query($con, $sql);
}


