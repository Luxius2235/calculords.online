<?php

include'conn.php';

$commid = $_POST['commid'];

$sqlb = "DELETE FROM pins WHERE commid = $commid;";
mysqli_query($con, $sqlb);
exit();