<?php

session_start();

include 'conn.php';
$error="";


if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}


if (isset($_POST['submit'])){

	$email = $_POST['email'];
    $pass = $_POST['pass'];

	if (empty($email) || empty($pass)){
		echo "Fill in all fields!";
	}



	elseif ($stmt = $con->prepare('SELECT id, pass, first FROM users WHERE email = ?')) {
		$stmt->bind_param('s', $_POST['email']);
		$stmt->execute();
		$stmt->store_result();
	
		if ($stmt->num_rows > 0) {
			$stmt->bind_result($id, $pass, $_POST['firstName']);
			$stmt->fetch();
			if (password_verify($_POST['pass'], $pass) ) {
				session_regenerate_id();
				$_SESSION['loggedin'] = TRUE;
				$_SESSION['name'] = $_POST['firstName'];
				$_SESSION['id'] = $id; ?>

				<html>
					<form id="form" action="learn.php" method="POST">
					<input type="hidden" name="status" value="loggedin">
					</form>
				</html>


				<script>
					document.getElementById("form").submit();
					window.location.href = 'comment.php';
				</script>


			<?php
			} else {
				echo "Email or Password is incorrect.";
			}
		} else {
			echo "Email or Password is incorrect.";
		}
	
	
		$stmt->close();
	} else {
        echo"there's a problem";
    }



};
?>

