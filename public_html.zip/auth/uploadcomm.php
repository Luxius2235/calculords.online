<?php
session_start();
include'conn.php';

if (empty($_POST['input'])) {
    echo "<script>console.log('pogiasd')</script>";
    exit();
};
$dess = $_POST['input'];
$id = $_SESSION['id']; 
$des = mysqli_real_escape_string($con,$_POST['input'] );
date_default_timezone_set('Asia/Manila');
$date = date('y-m-d H:i:s');
$sql = "INSERT INTO comments (comment, userid, time) VALUES ('$dess', '$id', '$date')";
mysqli_query($con, $sql);




