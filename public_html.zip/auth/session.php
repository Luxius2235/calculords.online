<?php

$stmt = $con->prepare('SELECT first, last, username, prof, role FROM users WHERE id = ?');
// In this case we can use the account ID to get the account info.
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($_SESSION['first'], $_SESSION['last'], $_SESSION['username'], $_SESSION['prof'], $_SESSION['role']);
$stmt->fetch();
$stmt->close();
$id = $_SESSION['id'];