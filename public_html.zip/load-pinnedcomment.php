<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>

<div class="reminder">
    <p>Please remember to maintain a positive and polite tone in the comment section. Let's foster a respectful and constructive environment for discussion. Thank you!</p>
  </div>

  <section>
    <span>Pinned Comments</span>
  </section>


<?php
  $commentnewcount = $_POST['commentnewcount'];
   $sqls = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof, pin.commid, pin.pinid FROM comments comm, pins pin, users usr WHERE comm.commid = pin.commid AND comm.userid = usr.id ORDER BY pin.pinid DESC LIMIT $commentnewcount ";
   $results =  mysqli_query($con, $sqls);
   while ($rows = mysqli_fetch_assoc($results)){




?>





<div class="user-comment-parent">

      <div class="user-comment-cont">
        <img src="Images/<?=$rows['prof']?>" alt="Profile">
        <section class="nametime-cont">
          <i><?=$rows['username']?></i>
          <i id="time"><?=getDateTimeDiff($rows['time']);?></i>
        </section>
        <?php
        if($_SESSION['role'] === 'developer') {
        ?>
        <i style="cursor:pointer;" class="fa-solid fa-thumbtack pinned unpin<?=$rows['commid']?>"></i>
        <?php 
        } else { ?>

          <i style="color:orange;" class="fa-solid fa-thumbtack pinned unpin"></i>
        <?php }
        ?>
        

        <?php
if($_SESSION['role'] === 'developer' or $_SESSION['id'] == $rows['userid']) {
?>
        <i class="fa-solid fa-trash ellipsis thrash<?=$rows['commid']?>"></i>

        <?php
}else {}
        ?>
      
      </div>

    <div>
      <section class="user-comment" style="margin-bottom:0;">
        <p><?=$rows['comment']?></p>
      </section>
      
    </div>
 
</div>



<?php
   };

?>



<script>

<?php
   $sqls = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof, pin.commid, pin.pinid FROM comments comm, pins pin, users usr WHERE comm.commid = pin.commid AND comm.userid = usr.id ORDER BY pin.pinid DESC";
   $results =  mysqli_query($con, $sqls);
   while ($rows = mysqli_fetch_assoc($results)){
?>

    $(".unpin<?=$rows['commid']?>").click(function(){
    console.log('<?=$rows['commid']?>');
    var userChoice = confirm("Are you sure you want unpin this comment?");
    if (userChoice) {
      

      commid = <?=$rows['commid']?>;
      $.ajax({
                url: 'auth/unpin.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
                  
                  
                }
            });

    } else {

    }
    });


    <?php   };
    ?>
</script>




