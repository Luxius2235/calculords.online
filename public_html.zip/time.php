<?php  

    $date = '2022-04=22 6:10:20';
 
 function getDateTimeDiff($date){ 
    date_default_timezone_set('Asia/Manila');
    $now_timestamp = strtotime(date('Y-m-d H:i:s')); 
    $diff_timestamp = $now_timestamp - strtotime($date); 

    if($diff_timestamp < 60){
         return 'few seconds ago'; 
        } 
    elseif($diff_timestamp >= 60 && $diff_timestamp<3600){ 

        if(round($diff_timestamp/60) == 1){
            return round($diff_timestamp/60).' min ago'; 
        }
        else{
            return round($diff_timestamp/60).' mins ago'; 
        }

       

        
    } 
     
    elseif($diff_timestamp >= 3600 && $diff_timestamp<86400){ 

        if(round($diff_timestamp/3600) == 1){
            return round($diff_timestamp/3600).
        ' hour ago'; 
        }
        else {
            return round($diff_timestamp/3600).
            ' hours ago'; 
        }
      
     } 
    elseif($diff_timestamp >= 86400 && $diff_timestamp<(86400*30))
        { 

            if(round($diff_timestamp/(86400)) == 1){
                return round($diff_timestamp/(86400)).
                ' day ago';
            }
            else{
                return round($diff_timestamp/(86400)).
            ' days ago';
            }
         } 
    elseif($diff_timestamp >= (86400*30) && $diff_timestamp < (86400*365))
         { 
            if(round($diff_timestamp/(86400*30)) == 1){
                    
            return round($diff_timestamp/
            (86400*30)).' month ago'; 
            }
            else {
                return round($diff_timestamp/
                (86400*30)).' months ago'; 
            }
            
            
            
           
            } 
    else { 
        
        if(round($diff_timestamp/(86400*365)) == 1){
            return round($diff_timestamp/(86400*365)).' year ago'; 
        }
        else{
            return round($diff_timestamp/(86400*365)).' years ago'; 
        }
        
        

    
    
    
    } 


    echo $date;
} 
               
           

        
