<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/top-nav-dark.css" rel="stylesheet">
    <link href="style/comment.css" rel="stylesheet">
    <link href="style/login-signup.css" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="images/favicon/icon1.svg">
    <script src="https://kit.fontawesome.com/63844d2341.js" crossorigin="anonymous"></script>
    <title>Gauss | Home</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    } 


    a{
  
      padding-top:1px;
    }

    .pinned:hover{
      color:orange;
    }

    .fa-solid{
      transition: all 0.5s;
    }

    .user-comment-parent{
      transition:all 1s;
    }

   

    .react-cont>button{
      background: none;
      border: none;
      height: 1rem;
      width: 1rem;
      margin-right: -1.8rem;
    
    }

    .fa-greater-than{
    transition:all 1s;
    cursor: pointer;
    background: none;
    border: none;

}
    </style>

</head>
<body>

    <div class="topBar">
        <i id="webName">C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></i> 
        <section class="barsclass">
            <i id="bars" class="fa-solid fa-bars"></i>
        </section>
    </div>

    <nav>

       <ul>
        <li id="home" onclick="location.href='index.php'"><i class="fa-solid fa-house fa-xl" ></i> Home</li>
        <li onclick="location.href='video.php'"><i class="fa-solid fa-video fa-xl" ></i> Video</li>
        <li id="comments" onclick="location.href='comment.php'"><i class="fa-solid fa-comment fa-xl" ></i> Comment</li>
        <li onclick="location.href='members.php'"><i class="fa-solid fa-person fa-xl"> </i> About us</li>
        <li onclick="location.href='references.php'"><i class="fa-brands fa-sourcetree fa-xl"></i> References</li>

        <?php
        if(!isset($_SESSION['loggedin'])){}
        else{
        ?> 


        <li onclick="location.href='auth/logout.php'"><i class="fa-solid fa-right-from-bracket fa-xl"></i> Log out</li>

        <?php
        }

?>
       </ul>
    </nav>

    <main class="mainParent">

    <?php

    if(!isset($_SESSION['loggedin'])){



?>
      <div class="texttop">
        <p id="texttop"></p></p>
      </div>

   
    

    <div class="containersign saynap "> 

      <h1 class="login-name">C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></h1>

      <form class="signup register" autocomplete="on">

        <section class="namecont siksyon">
            <span>Enter Name</span>
            <input id="first" name="first" placeholder="First Name">
            <input id="last" name="last" placeholder="Last Name">
        </section>
        
        <section class="siksyon">
          <span>Username</span>
          <input id="pass" class="userreg" name="username" placeholder="Enter username">
      </section>
          

          <section class="siksyon">
              <span>Email</span>
              <input class="emailreg" id="email" type="email" name="email" placeholder="Enter Email">
          </section>
          
          <section class="siksyon"> 
              <span>Password</span>
              <input id="pass" class="passreg" type="password" name="pass" placeholder="Enter Password">
           </section>
           <section class="showpass"> 
            <input type="checkbox" onclick="showPass()">
            <a>Show Password</a>
          </section>

          <button name="submit" type="submit" class="submit" style="align-self: center; width: 100%;">Register</button>
      </form>

      <br>
      <section>

       <p class="ques">Have an account? <a class="anchor log">Login here. </a></p>
      <span class='error' style="color:red"></span>


       
       

      </section>
  </div>

  <div class="containersign lagin"> 

    <h1>C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></h1>

    <form class="signup login" autocomplete="on">
        <section class="siksyon">
            <span>Email</span>
            <input id="email" class="emaillog" type="email" name="email" placeholder="Enter Email">
        </section>
        
        <section class="siksyon">
            <span>Password</span>
            <input id="pass" class="passlog" type="password" name="pass" placeholder="Enter Password">
        </section>

        <button type="submit" class="submit" style="align-self: center; width: 100%;">Log in</button>
    </form>

    <br>
    <section>

     <p class="ques">Don't have an account? <a class="anchor reg">Register here. </a></p>
    <span class='Error'></span>
    
    </section>
</div>
<?php

    }else{

?>
<main class="hideme">


<main id="loadpinnedcomment" class="pinned-comment-cont">
 

</main>


<form  id="commform" class="input-comment-cont">
  <img src="Images/<?=$_SESSION['prof']; ?>" alt="">
  <textarea name="input" class="comments" rows="1" cols="1" placeholder="Comment"></textarea>
  <button id="postcomm"><i class="fa-solid fa-paper-plane"></i></button>
</form>


<main id="loadcomment" class="user-comment-main-cont">

</main>


<?php

    };

?>









</main>





</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>//load and show

$(document).ready(function(){

  loadcomm();
  pinedcomm();
  

 

  $('#postcomm').on('click',function(e){
      e.preventDefault(); 
      console.log('asdasd');
        $.ajax({
            url:'auth/uploadcomm.php',
            type:'POST',
            data: $('#commform').serialize(),
            success:function(response){
                $(".comments").val("");
                loadcomms();
                
           
            }
        });
    });

  


  function pinedcomm() {                                       /* load pin starting   */
  let commentcount = 50;

  $("#loadpinnedcomment").load("load-pinnedcomment.php", {
    commentnewcount: commentcount
  });
};

var commentcount = 50
function pinedcomms() {                                      
  let commentcount = 50 + 50; 

  $("#loadpinnedcomment").load("load-pinnedcomment.php", {
    commentnewcount: commentcount
  });
};

setInterval(pinedcomms, 1000);









  function loadcomm() {                                       /* load comment starting   */
  
  let commentcount = 50;

  $("#loadcomment").load("load-comment.php", {
    commentnewcount: commentcount
  },function(response){
  
  }
  );
};


var commentcount = 50;
function loadcomms(){

  commentcount = commentcount + 50  ;

  $("#loadcomment").load("load-comment.php", {
    commentnewcount: commentcount
  },function(response){
  
  }
  );

}


setInterval(loadcomms, 1000);



  $('.hideme').show();

  $(".texttop").show();
  $(".lagin").show();



  $("#ellipsis-box").hide();

  $("#texttop").text("Want to say something?");
  $(".saynap").hide();
}); 

$(".reg").click(function(){
    $(".saynap").show();
    $(".lagin").hide();
    $("#texttop").text("Poor thing.. you must be new here.");
  });

$(".log").click(function(){
    $(".lagin").show();
    $(".saynap").hide();
    $("#texttop").text("I always new you're familiar!");
  });

</script>


<script> //login and register
$(document).ready(function() {


        $(".register").submit(function(event) {
            event.preventDefault();
            var firstName = $("#first").val();
            var lastName = $("#last").val();
            var email = $(".emailreg").val();
            var pass = $(".passreg").val();
            var username = $(".userreg").val();
            $(".error").load("auth/authReg.php", {
                firstName:firstName,
                lastName:lastName,
                email: email,
                pass: pass,
                username:username, 
                submit:'submit'
            });
        });


        $(".login").submit(function(event) {
            event.preventDefault();
            var email = $(".emaillog").val();
            var pass = $(".passlog").val();
            $(".Error").load("auth/authLogin.php", {
                email: email,
                pass: pass,
                submit:'submit'
            });
        });


    });

</script>
<script> //show pass
function showPass() {
  console.log('damn');

  let inputPass = document.getElementsByClassName("passreg")[0];
  if (inputPass.type === "password") {
    inputPass.type = "text";
  } else {
    inputPass.type = "password";
  }
}

</script>

<script>


$(document).ready(function(){

    
    $(".mathDropdown").hide();

    $(".navDropdown").hide();

  $("#subtopic").click(function(){
    $(".navDropdown").fadeToggle("fast");
    $(this).toggleClass('subtopicclass');
  });


  $("#chap4").click(function(){
    $(".mathDropdown").fadeToggle("fast");
    var currentColor = $(this).css("color");

    // Toggle between default color and orange
    var newColor = (currentColor === "rgb(255, 165, 0)") ? "" : "orange";
    
    // Apply the new color
    $(this).css("color", newColor);

  });

  $("#bars").click(function(){
    var nav = $("nav");

if (nav.hasClass("navshow")) {
    nav.removeClass("navshow");
} else {
    nav.addClass("navshow");
}

  });


  


  function checkWidth() {
    var element = $('nav');
    if ($(window).width() < 670) {
      element.addClass('navhide');   

      $(".mainParent").click(function(){
        $("nav").removeClass('navshow');
        console.log("pogi");
    })
      
      
  

    } else {
      
        console.log("fck u");


    }
  }

  // Initial check when the page loads
  checkWidth();

  // Add event listener for window resize
  $(window).resize(checkWidth);
});

</script>



<script> 

<?php
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof, usr.id  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){

    $ids = $row['id'];}
?>


$(document).ready(function(){
		
    $(document).on('click', '.like', function(){



        var id=$(this).val();
        var $this = $(this);

        console.log(id);



        $this.toggleClass('like');


        if($this.hasClass('like')){
            $this.css({"border": "solid 1px rgba(0, 0, 0, 0.344); "});
            $this.html("<i class='fa-solid fa-greater-than fa-xl' style='color: gray;'></i>");
          




        } else {
       

         $this.addClass("unlike"); 

    
         $this.html("<i class='fa-solid fa-greater-than fa-xl' style='color: orange;'></i> ");
         $this.css({"border": "solid 1px rgba(0, 0, 0, 0.344); "});
         



        }
            $.ajax({
                type: "POST",
                url: "like.php",
                data: {
                    id: id,
                    postuserid:"<?php echo $ids?>",
                    like: 1,
                },
                success: function(){
                    showLike(id);
                }
            });
    });
    
    $(document).on('click', '.unlike', function(){
        var id=$(this).val();
        var $this = $(this);
        $this.toggleClass('unlike');


        if($this.hasClass('unlike')){
            
        
            $this.html("<i class='fa-solid fa-greater-than fa-xl' style='color: orange;'></i> ");
           $this.css({"border": "solid 1px rgba(0, 0, 0, 0.344); "});



        } else {
         
           

        $this.addClass("like"); 
        $this.css({"border": "solid 1px rgba(0, 0, 0, 0.344); "});
        $this.html("<i class='fa-solid fa-greater-than fa-xl' style='color: gray;'></i>");
        
        }
            $.ajax({
                type: "POST",
                url: "like.php",
                data: {
                  id: id,
                  postuserid:"<?php echo $ids?>",
                  like: 1,
                },
                success: function(){
                    showLike(id);
                }
            });
    });
    
});



function showLike(id){
    $.ajax({
        url: 'show_like.php',
        type: 'POST',
        async: false,
        data:{
            postuserid:"<?php echo $ids?>",
            id: id,
            showlike: 1
        },
        success: function(response){
            $('#show_like'+id).html(response);
            
        }
    });
}

</script>

<script>

<?php
   $sqls = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof, pin.commid, pin.pinid FROM comments comm, pins pin, users usr WHERE comm.commid = pin.commid AND comm.userid = usr.id ORDER BY pin.pinid DESC";
   $results =  mysqli_query($con, $sqls);
   while ($rows = mysqli_fetch_assoc($results)){
?>

    $(".unpin<?=$rows['commid']?>").click(function(){
    console.log('<?=$rows['commid']?>');
    var userChoice = confirm("Are you sure you want unpin this comment?");
    if (userChoice) {
      

      commid = <?=$rows['commid']?>;
      $.ajax({
                url: 'auth/unpin.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
                  
                  
                }
            });

    } else {

    }
    });


    <?php   };
    ?>
</script>

<script>

<?php
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){
?>

    $(".thrash<?=$row['commid']?>").click(function(){
   
    var userChoice = confirm("Are you sure you want to delete this?");
    if (userChoice) {
    
      commid = <?=$row['commid']?>;
      $.ajax({
                url: 'auth/deletecomm.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
               
                }
            });

            console.log('pogiako');
    } else {

    }
    });

    <?php

   };

?>
  </script>

<script> 
  
<?php
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){
?>

    


    $(".pin<?=$row['commid']?>").click(function(){
      console.log('<?=$row['commid']?>')
    var userChoice = confirm("Are you sure you want pin this comment?");
    if (userChoice) {
      commid = <?=$row['commid']?>;
      $.ajax({
                url: 'auth/pin.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
                  
                  
                }
            });
    } else {

    }
    });

    <?php
   };

?>





  
  </script>

</html>