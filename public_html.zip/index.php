<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon/icon1.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/63844d2341.js" crossorigin="anonymous"></script>
    <title>Gauss | Home</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    } 
    
    nav{
    transition: all 1s; 
  }

      @media screen and (max-width: 1300px) {
    * {
      padding: 0;
      margin: 0;
    }
    
    #title1 {
      font-size: 7rem;
    }
  
    .contentParent {
      flex-direction: column;
    }
  
    #frontimage {
      height: 10rem;
      object-fit: cover;
    }
  
    .introduction {
      width: 100%;
    }
  }
  

@media screen and (max-width: 670px){

.introduction {
    padding:1rem;
    width:auto;
}
}
    </style>



</head>
<body>

    <div class="topBar" id="topBar">
    <i id="webName"> C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></i> 

    <section class="option">
        <i class="fa-solid fa-moon moon"></i>
        <i class="fa-solid fa-highlighter highlighter"></i>
    </section>
    <section class="barsclass">
        <i id="bars" class="fa-solid fa-bars"></i>
    </section>
    
    </div>

    <nav class="nav">

       <ul>
        <li id="home" class="home-white" onclick="location.href='index.php'"><i class="fa-solid fa-house fa-xl" ></i> Home</li>
        <li id="subtopic"><i class="fa-solid fa-subscript fa-xl" ></i> Subtopics <i class="fa-solid fa-caret-down" ></i></li>
        <ul class="navDropdown">
            <li id="chap1">Introduction</li>
            <li id="chap2">Childhood and Education </li>
            <li id="chap3" style="padding-top: 5%;">University Studies and Early Mathematical Works </li>
            <li id="chap4">Mathematical Genius <i class="fa-solid fa-caret-down" ></i></li>
                <ul class="mathDropdown">
                    <li id="chap4-1">Gauss's Mathematical Contributions</li>
                    <li id="chap4-2">Gauss's Impact Beyond Mathematics</li>
                </ul>
            <li id="chap5">Death and Legacy</li>
            <li id="chap6">Conclusion</li>
        </ul>
     </section>
        <li onclick="location.href='video.php'"><i class="fa-solid fa-video fa-xl" ></i> Video</li>
        <li onclick="location.href='comment.php'"><i class="fa-solid fa-comment fa-xl" ></i> Comment</li>
        <li onclick="location.href='members.php'"><i class="fa-solid fa-person fa-xl"> </i> About us</li>
        <li onclick="location.href='references.php'"><i class="fa-brands fa-sourcetree fa-xl" ></i> References</li>

            
        <?php
        if(!isset($_SESSION['loggedin'])){}
        else{
        ?> 


        <li onclick="location.href='auth/logout.php'"><i class="fa-solid fa-right-from-bracket fa-xl"></i> Log out</li>

        <?php
        }

?>


       </ul>






        
    </nav>

    <main class="mainParent">
      
    
        <div class="contentParent">
            <img class="left gaussimg" id="frontimage" src="Images/gauss.jpg" alt="I'm GAUSS">
            <div class="parentTitle right">
                <p id="title1">GAUSS:</p>
                <p id="title2">The greatest Mathematician since Antiquity</p>
            </div>
        </div>

        <div class="introduction">
            <p id="title">Chapter 1: Introduction</p>

            <p id="subcontent">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;One of <a class="i">history's greatest mathematicians and scientists</a>, Johann Carl Friedrich Gauss, had an extraordinary childhood that served as the foundation for his later successes. Gauss's early years were marked by an outstanding ability for mathematics and an enthusiasm for learning. He was born on April 30, 1777, in Brunswick, a city in the Duchy of Brunswick-Wolfenbüttel, which is today a part of Germany.
            </p>

            <p id="subcontent">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In a modest working-class family, Gauss was born in the latter half of the eighteenth century. His father, Gebhard Dietrich Gauss, was a mason. Gebhard Dietrich Gauss was born on February 13, 1744, and assisted his father in business in Brunswick, Germany. Gauss worked as a sales assistant, butcher, bricklayer, gardener, treasurer, and treasurer for a nearby insurance company, among other jobs, to make ends meet. There was always a shortage of money. On April 28, 1768, he married Dorothea Emerenzia Warnecken Sollerieh, and to this marriage was born one son, Johann George Heinrich, on January 14, 1769. The mother died on September 5, 1775, aged thirty (30) years. Gauss’s father had a previous marriage that ended, and Georg was his older half-brother from the first marriage. Gebhard Dietrich married Dorothea Bentze, the daughter of Christopher Bentze, a stone mason, on April 25, 1776, in Velpke, a small village near Brunswick. She was born on April 21, 1755. Their only child, Carl Friedrich Gauss, was born on April 30, 1777. His mother, Dorothea Benze, was a housewife. Gauss’s mother was illiterate, having worked as a housemaid before getting married and never having received any formal education. The birthplace of Carl Friedrich Gauss was a small house in a street called “Wendengraben”. Later, the address of the house was changed to “Wilhelmstrasse 30.”

            </p>

            <p id="subcontent">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dorothea Gauss lived to the age of ninety-seven (97) and spent the last twenty-two (22) years of her life under the loving care of her son at the Gottingen observatory. Gauss and his father never had any quarrels, but in his home, Gebhard Dietrich was often dominating and uncouth. He died on April 14, 1808. On April 18, 1839, Frau Dorothea Gauss, the mother of Carl Friedrich, died. She had always been very proud of her only son, and he showed the greatest affection for her. She had become blind several years before her death, but this did not stop her usual activity.
            </p>
        </div>
    


    <div class="introduction chap2">
        <p id="title">Chapter 2: Childhood and Education</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss showed a great capacity for mental calculations from an early age. Due to his mathematical capabilities, Gauss mostly worked on his inventions on his own. He had a very complicated and hard childhood. Gauss taught himself how to read. His teachers were very astonished by what Gauss was able to accomplish at a very young age. Despite this, Gauss’s father was strict in ensuring that Gauss focused on his studies.
            
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To add to that, politics played a huge part in his life. Gauss's first mentor was his elementary school teacher, Herr Büttner. Herr Büttner recognized Gauss's exceptional mathematical abilities at an early age. Gauss's remarkable talent is demonstrated by the well-known account of him summing the numbers from 1 to 100 while still in elementary school. Admiring Gauss's resourcefulness, Herr Büttner resolved to develop the young prodigy's abilities. He gave Gauss books on advanced mathematics and pushed him to solve difficult problems that went way beyond the syllabus. Gauss's love for mathematics and his aptitude for mathematics were greatly influenced by Herr Büttner's mentoring. With his knowledge, a lot of people tried to exploit Gauss so his father and Gauss’s mentor supplied him with books to motivate him to study and develop himself more.


        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss craved greater intellectual challenges as his studies advanced. Around this time, he met Professor Wolfgang Bolyai, a well-known mathematician at the University of Helmstedt, who would become his second mentor. Gauss was mentored by Professor Bolyai, who saw his promise. Gauss showed his natural mathematical capabilities by discovering a straightforward formula that allowed him to compute the sum quickly while other kids found it difficult to complete this very difficult task. In the year 1788, Gauss began studying at Gymnasium, a secondary school located in Germany where he continued to excel in mathematics and displayed an immense need for knowledge. His education, however, was not limited to mathematics. He also studied Latin, Greek, and other subjects that other students take in school, which would later prove to be very advantageous in his mathematical work. Gauss maintained his mathematical ability while he was a student at the Carolinum Gymnasium. He was lucky to have J.G. as a math teacher. Bartels, who appreciated his special abilities and supported his academic endeavors. Bartels was a key figure in Gauss's development, helping him with his studies and exposing him to works on advanced mathematics. Gauss started to formulate his own mathematical theories and make novel contributions to the area while being mentored by Bartels. At the age of 14, he was given an allowance from the duke which allowed him to focus his attention in his studies. There, he discovered the binomial theorem and the law of quadratic reciprocity.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From a young age, Carl Friedrich Gauss made substantial contributions to the field of mathematics, and his impact could be seen in both academic and practical contexts. His works, from an early age played a significant part in our fundamental understandings of the world. For example, at the age of 15, Gauss found a formula to find the sum of the first natural numbers and even found a way to find the product of these numbers. Furthermore, he also developed a way to figure out if a given number is a prime number. He started to add to the mathematical knowledge of his era after absorbing it. At the age of 19, he achieved a great feat in building the heptadecagon, a 17-sided polygon, which pioneered his future mathematical breakthroughs. In the field of statistics, Gauss developed the least squares method. This allowed individuals to minimize the sum of squares between the observed and calculated values.

        </p>
    </div>

    <div class="introduction chap3">
        <p id="title">Chapter 3: Childhood and Education</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In 1784, Gauss enrolled in a primary school and was placed in a class with fifty other students. Prior to attending school, Gauss had already acquired the ability to read and write, seemingly without any assistance from his parents. Gauss's exceptional intelligence was acknowledged by his humble but dedicated parents. In 1784, while he was a student at an elementary school. When he was just ten years old, he astonished his teacher by mentally computing the sum of all the numbers from 1 to 100. Gauss clarified that he had observed a pattern that implied a formula, and in any case, he arrived at the correct answer nearly instantaneously. In 1788, Gauss commenced his formal education at the Gymnasium, under the guidance of teachers Büttner and Bartels. During his time there, he acquired proficiency in High German and Latin. In 1792, thanks to a financial grant from the Duke of Brunswick-Wolfenbüttel, Gauss gained entry to the Brunswick Collegium Carolinum. At the academy, Gauss embarked on a remarkable intellectual journey. He independently made significant discoveries, including Bode's law, which relates to the spacing of planets in the solar system. He also explored the binomial theorem, a fundamental concept in mathematics, and delved into the arithmetic-geometric mean. Additionally, Gauss contributed to mathematical theory by formulating the law of quadratic reciprocity and making important contributions to the prime number theorem, which deals with the distribution of prime numbers. During his teenage years, Gauss embarked on an independent journey of exploration into advanced mathematical principles. Remarkably, in 1795, at the young age of 18, he achieved a historic milestone by becoming the very first person to provide a rigorous proof for the Law of Quadratic Reciprocity. This mathematical theory is fundamental in determining the solvability of quadratic equations. Coinciding with this achievement, he commenced his academic studies at Gottingen University in the same year. In 1796, while pursuing his education at the university, Gauss accomplished one of his most significant breakthroughs. Armed only with a ruler and compass, he ingeniously constructed a regular polygon with 17 sides, known as a heptadecagon. As he delved into the underlying theory of this geometric feat, Gauss unveiled a profound and groundbreaking connection between algebra and geometrical shapes. In doing so, he successfully culminated the work that had its roots in the endeavors of classical Greek mathematicians. Gauss's contributions not only revolutionized the landscape of contemporary mathematics but also added substantial weight to the ongoing research initially instigated by the renowned 16th-century French philosopher and mathematician, René Descartes. Gauss's work has had a profound and enduring impact on the world of mathematics and continues to be celebrated for its groundbreaking insights. In 1796, Gauss achieved the distinction of being the world's first mathematician to offer a proof for the Law of Quadratic Reciprocity in the field of number theory. He aptly referred to this achievement as the "fundamental" or "golden theorem." Additionally, in the same year, he formulated the Prime Number Theorem, even though he chose not to publish it. In Gauss's doctoral dissertation of 1799, he engaged in a profound exploration of the first proof of the fundamental theorem of algebra. This fundamental theorem asserts that any polynomial equation with complex coefficients must possess at least one complex root. Gauss's meticulous examination and elucidation of this theorem showcased his early brilliance in mathematical reasoning. Furthermore, Gauss made noteworthy contributions to understanding the number of solutions for polynomial equations that had coefficients within finite fields. This particular investigation laid the groundwork for the Weil conjectures, formulated in 1949. The Weil conjectures, building upon Gauss's earlier insights, represent a set of conjectures that delve into the intricate relationships between the solutions of polynomial equations over finite fields and various geometric objects. Gauss's foundational work in this area not only demonstrated his mathematical prowess but also paved the way for subsequent developments in algebraic geometry and number theory.In 1801, Carl Friedrich Gauss published his significant work, the "Disquisitiones Arithmeticae" (DA), despite facing initial rejection from the Paris Academy. This groundbreaking work introduced congruence notation, which played a crucial role in presenting a proof for the fundamental theorem of arithmetic. Additionally, Gauss formalized parametric solutions to indeterminate equations in the DA. An interesting aspect highlighted by Gauss' biographer, Dunnington, was the inclusion of library check-out card references in the appendix of the DA. These references shed light on Gauss' diverse interests as a graduate student, showcasing the breadth of his intellectual curiosity. In the same year, 1801, Italian 
astronomer Joseph Piazzi discovered the planetoid Ceres. However, he could only observe it for a brief period. Remarkably, Gauss accurately predicted the position at which Ceres could be rediscovered. Zach rediscovered it on December 31, 1801, in Gotha, followed by Olbers in Bremen a day later. Zach acknowledged Gauss's contributions, stating, "Without the intelligent work and calculations of Doctor Gauss, we might not have found Ceres again." Building on this success and the subsequent discovery of the planetoid Pallas by Olbers in 1802, Gauss delved into developing a theory on the motion of planetoids disturbed by larger planets. This comprehensive work was eventually published in 1809 under the title "Theoria motus corporum coelestium in sectionibus conicis solem ambientum" (Theory of the motion of celestial bodies moving in conic sections around the sun). Gauss's dedication to celestial mechanics and his ability to apply mathematical rigor to astronomical predictions solidified his reputation as a brilliant mathematician and astronomer during this period.

            
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss left an indelible mark on the realm of Number Theory, often expressing his deep reverence for the subject by asserting that "Mathematics is the queen of sciences, and number theory is the queen of mathematics." Demonstrating exceptional mathematical insight, Gauss, at the young age of 24, made a seminal contribution to the field in 1801 with the publication of his magnum opus, "Disquisitiones Arithmeticae." Widely regarded as the most influential work in the field of number theory, "Disquisitiones Arithmeticae" stands as a testament to Gauss's unparalleled intellect. In this groundbreaking book, he delved into intricate mathematical concepts, providing profound insights and establishing foundational principles that would shape the course of number theory for generations to come. Gauss's enduring impact on the field is not only evident in the elegance of his mathematical formulations but also in his ability to elevate number theory to a position of paramount importance within the broader scientific landscape.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss revolutionized number theory through the introduction of the concept of congruence, a method of establishing agreement between numbers. Central to this innovation was the utilization of "modulos" or defined sets of numbers, allowing for the subdivision of the infinite series of whole numbers into more manageable segments. This ingenious theory of congruence enabled the simplification of computations by breaking down complex arithmetic tasks, making them more amenable to programming in computer systems. According to Gauss's proposition, when one number is subtracted from another (a - b), if the remainder of this subtraction is divisible by another number, denoted as m, then a and b are considered congruent to each other modulo m. Gauss articulated this relationship with the concise formula: a is congruent to b modulo c. As an illustration, consider the subtraction 720 - 480, resulting in a remainder of 240. This remainder is divisible by 60, 20, 10, and other numbers, but for the sake 
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;of illustration, let's focus on 60. Applying Gauss's expression, we can assert that 720 is congruent to 480 modulo 60. In essence, both 720 and 480 share a mathematical connection through a third number (the remainder after subtracting 480 from 720), which can be expressed as a multiple of 60. This elegant concept not only enhances computational efficiency but also finds practical application in diverse areas, such as timekeeping algorithms in computer programming. In a conceptual sense, this mathematical process finds practical application in everyday tasks such as interpreting the time displayed on a digital watch. Instead of stating "240 minutes past noon," the digital watch simplifies the information to "4 o'clock" or "4:00." This temporal representation involves the use of various modulos, or defined measures, which have been employed for centuries. For instance, there are 60 minutes in an hour and 12 hours in the a.m. or p.m. of a day. Consider the scenario where a digital watch indicates 4:00 in the afternoon. From a particular perspective, this translates to subtracting 480 minutes from the 720-minute period between 12 noon and midnight. The result is 240 minutes past noon (720 - 480 = 240). This remaining time, 240 minutes, aligns evenly with the modulo 60 (as well as other numbers we will overlook), illustrating the seamless integration of Gauss's modular arithmetic principles into the practical functionality of digital timekeeping.


        </p>
    </div>  

    <div class="introduction chap4-1">
        <p id="title">Chapter 4.1: Gauss's Mathematical Contributions</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss showed a great capacity for mental calculations from an early age. Due to his mathematical capabilities, Gauss mostly worked on his inventions on his own. He had a very complicated and hard childhood. Gauss taught himself how to read. His teachers were very astonished by what Gauss was able to accomplish at a very young age. Despite this, Gauss’s father was strict in ensuring that Gauss focused on his studies.
            
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To add to that, politics played a huge part in his life. Gauss's first mentor was his elementary school teacher, Herr Büttner. Herr Büttner recognized Gauss's exceptional mathematical abilities at an early age. Gauss's remarkable talent is demonstrated by the well-known account of him summing the numbers from 1 to 100 while still in elementary school. Admiring Gauss's resourcefulness, Herr Büttner resolved to develop the young prodigy's abilities. He gave Gauss books on advanced mathematics and pushed him to solve difficult problems that went way beyond the syllabus. Gauss's love for mathematics and his aptitude for mathematics were greatly influenced by Herr Büttner's mentoring. With his knowledge, a lot of people tried to exploit Gauss so his father and Gauss’s mentor supplied him with books to motivate him to study and develop himself more.


        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss craved greater intellectual challenges as his studies advanced. Around this time, he met Professor Wolfgang Bolyai, a well-known mathematician at the University of Helmstedt, who would become his second mentor. Gauss was mentored by Professor Bolyai, who saw his promise. Gauss showed his natural mathematical capabilities by discovering a straightforward formula that allowed him to compute the sum quickly while other kids found it difficult to complete this very difficult task. In the year 1788, Gauss began studying at Gymnasium, a secondary school located in Germany where he continued to excel in mathematics and displayed an immense need for knowledge. His education, however, was not limited to mathematics. He also studied Latin, Greek, and other subjects that other students take in school, which would later prove to be very advantageous in his mathematical work. Gauss maintained his mathematical ability while he was a student at the Carolinum Gymnasium. He was lucky to have J.G. as a math teacher. Bartels, who appreciated his special abilities and supported his academic endeavors. Bartels was a key figure in Gauss's development, helping him with his studies and exposing him to works on advanced mathematics. Gauss started to formulate his own mathematical theories and make novel contributions to the area while being mentored by Bartels. At the age of 14, he was given an allowance from the duke which allowed him to focus his attention in his studies. There, he discovered the binomial theorem and the law of quadratic reciprocity.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From a young age, Carl Friedrich Gauss made substantial contributions to the field of mathematics, and his impact could be seen in both academic and practical contexts. His works, from an early age played a significant part in our fundamental understandings of the world. For example, at the age of 15, Gauss found a formula to find the sum of the first natural numbers and even found a way to find the product of these numbers. Furthermore, he also developed a way to figure out if a given number is a prime number. He started to add to the mathematical knowledge of his era after absorbing it. At the age of 19, he achieved a great feat in building the heptadecagon, a 17-sided polygon, which pioneered his future mathematical breakthroughs. In the field of statistics, Gauss developed the least squares method. This allowed individuals to minimize the sum of squares between the observed and calculated values.

        </p>
    </div>

    <div class="introduction chap4-2">
        <p id="title">Chapter 4.2: Gauss's Impact Beyond Mathematics</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss showed a great capacity for mental calculations from an early age. Due to his mathematical capabilities, Gauss mostly worked on his inventions on his own. He had a very complicated and hard childhood. Gauss taught himself how to read. His teachers were very astonished by what Gauss was able to accomplish at a very young age. Despite this, Gauss’s father was strict in ensuring that Gauss focused on his studies.
            `
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To add to that, politics played a huge part in his life. Gauss's first mentor was his elementary school teacher, Herr Büttner. Herr Büttner recognized Gauss's exceptional mathematical abilities at an early age. Gauss's remarkable talent is demonstrated by the well-known account of him summing the numbers from 1 to 100 while still in elementary school. Admiring Gauss's resourcefulness, Herr Büttner resolved to develop the young prodigy's abilities. He gave Gauss books on advanced mathematics and pushed him to solve difficult problems that went way beyond the syllabus. Gauss's love for mathematics and his aptitude for mathematics were greatly influenced by Herr Büttner's mentoring. With his knowledge, a lot of people tried to exploit Gauss so his father and Gauss’s mentor supplied him with books to motivate him to study and develop himself more.


        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss craved greater intellectual challenges as his studies advanced. Around this time, he met Professor Wolfgang Bolyai, a well-known mathematician at the University of Helmstedt, who would become his second mentor. Gauss was mentored by Professor Bolyai, who saw his promise. Gauss showed his natural mathematical capabilities by discovering a straightforward formula that allowed him to compute the sum quickly while other kids found it difficult to complete this very difficult task. In the year 1788, Gauss began studying at Gymnasium, a secondary school located in Germany where he continued to excel in mathematics and displayed an immense need for knowledge. His education, however, was not limited to mathematics. He also studied Latin, Greek, and other subjects that other students take in school, which would later prove to be very advantageous in his mathematical work. Gauss maintained his mathematical ability while he was a student at the Carolinum Gymnasium. He was lucky to have J.G. as a math teacher. Bartels, who appreciated his special abilities and supported his academic endeavors. Bartels was a key figure in Gauss's development, helping him with his studies and exposing him to works on advanced mathematics. Gauss started to formulate his own mathematical theories and make novel contributions to the area while being mentored by Bartels. At the age of 14, he was given an allowance from the duke which allowed him to focus his attention in his studies. There, he discovered the binomial theorem and the law of quadratic reciprocity.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From a young age, Carl Friedrich Gauss made substantial contributions to the field of mathematics, and his impact could be seen in both academic and practical contexts. His works, from an early age played a significant part in our fundamental understandings of the world. For example, at the age of 15, Gauss found a formula to find the sum of the first natural numbers and even found a way to find the product of these numbers. Furthermore, he also developed a way to figure out if a given number is a prime number. He started to add to the mathematical knowledge of his era after absorbing it. At the age of 19, he achieved a great feat in building the heptadecagon, a 17-sided polygon, which pioneered his future mathematical breakthroughs. In the field of statistics, Gauss developed the least squares method. This allowed individuals to minimize the sum of squares between the observed and calculated values.

        </p>
    </div>

    
    <div class="introduction chap5">
        <p id="title">Chapter 5: Death and Legacy</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In 1784, Gauss enrolled in a primary school and was placed in a class with fifty other students. Prior to attending school, Gauss had already acquired the ability to read and write, seemingly without any assistance from his parents. Gauss's exceptional intelligence was acknowledged by his humble but dedicated parents. In 1784, while he was a student at an elementary school. When he was just ten years old, he astonished his teacher by mentally computing the sum of all the numbers from 1 to 100. Gauss clarified that he had observed a pattern that implied a formula, and in any case, he arrived at the correct answer nearly instantaneously. In 1788, Gauss commenced his formal education at the Gymnasium, under the guidance of teachers Büttner and Bartels. During his time there, he acquired proficiency in High German and Latin. In 1792, thanks to a financial grant from the Duke of Brunswick-Wolfenbüttel, Gauss gained entry to the Brunswick Collegium Carolinum. At the academy, Gauss embarked on a remarkable intellectual journey. He independently made significant discoveries, including Bode's law, which relates to the spacing of planets in the solar system. He also explored the binomial theorem, a fundamental concept in mathematics, and delved into the arithmetic-geometric mean. Additionally, Gauss contributed to mathematical theory by formulating the law of quadratic reciprocity and making important contributions to the prime number theorem, which deals with the distribution of prime numbers. During his teenage years, Gauss embarked on an independent journey of exploration into advanced mathematical principles. Remarkably, in 1795, at the young age of 18, he achieved a historic milestone by becoming the very first person to provide a rigorous proof for the Law of Quadratic Reciprocity. This mathematical theory is fundamental in determining the solvability of quadratic equations. Coinciding with this achievement, he commenced his academic studies at Gottingen University in the same year. In 1796, while pursuing his education at the university, Gauss accomplished one of his most significant breakthroughs. Armed only with a ruler and compass, he ingeniously constructed a regular polygon with 17 sides, known as a heptadecagon. As he delved into the underlying theory of this geometric feat, Gauss unveiled a profound and groundbreaking connection between algebra and geometrical shapes. In doing so, he successfully culminated the work that had its roots in the endeavors of classical Greek mathematicians. Gauss's contributions not only revolutionized the landscape of contemporary mathematics but also added substantial weight to the ongoing research initially instigated by the renowned 16th-century French philosopher and mathematician, René Descartes. Gauss's work has had a profound and enduring impact on the world of mathematics and continues to be celebrated for its groundbreaking insights. In 1796, Gauss achieved the distinction of being the world's first mathematician to offer a proof for the Law of Quadratic Reciprocity in the field of number theory. He aptly referred to this achievement as the "fundamental" or "golden theorem." Additionally, in the same year, he formulated the Prime Number Theorem, even though he chose not to publish it. In Gauss's doctoral dissertation of 1799, he engaged in a profound exploration of the first proof of the fundamental theorem of algebra. This fundamental theorem asserts that any polynomial equation with complex coefficients must possess at least one complex root. Gauss's meticulous examination and elucidation of this theorem showcased his early brilliance in mathematical reasoning. Furthermore, Gauss made noteworthy contributions to understanding the number of solutions for polynomial equations that had coefficients within finite fields. This particular investigation laid the groundwork for the Weil conjectures, formulated in 1949. The Weil conjectures, building upon Gauss's earlier insights, represent a set of conjectures that delve into the intricate relationships between the solutions of polynomial equations over finite fields and various geometric objects. Gauss's foundational work in this area not only demonstrated his mathematical prowess but also paved the way for subsequent developments in algebraic geometry and number theory.In 1801, Carl Friedrich Gauss published his significant work, the "Disquisitiones Arithmeticae" (DA), despite facing initial rejection from the Paris Academy. This groundbreaking work introduced congruence notation, which played a crucial role in presenting a proof for the fundamental theorem of arithmetic. Additionally, Gauss formalized parametric solutions to indeterminate equations in the DA. An interesting aspect highlighted by Gauss' biographer, Dunnington, was the inclusion of library check-out card references in the appendix of the DA. These references shed light on Gauss' diverse interests as a graduate student, showcasing the breadth of his intellectual curiosity. In the same year, 1801, Italian 
astronomer Joseph Piazzi discovered the planetoid Ceres. However, he could only observe it for a brief period. Remarkably, Gauss accurately predicted the position at which Ceres could be rediscovered. Zach rediscovered it on December 31, 1801, in Gotha, followed by Olbers in Bremen a day later. Zach acknowledged Gauss's contributions, stating, "Without the intelligent work and calculations of Doctor Gauss, we might not have found Ceres again." Building on this success and the subsequent discovery of the planetoid Pallas by Olbers in 1802, Gauss delved into developing a theory on the motion of planetoids disturbed by larger planets. This comprehensive work was eventually published in 1809 under the title "Theoria motus corporum coelestium in sectionibus conicis solem ambientum" (Theory of the motion of celestial bodies moving in conic sections around the sun). Gauss's dedication to celestial mechanics and his ability to apply mathematical rigor to astronomical predictions solidified his reputation as a brilliant mathematician and astronomer during this period.

            
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss left an indelible mark on the realm of Number Theory, often expressing his deep reverence for the subject by asserting that "Mathematics is the queen of sciences, and number theory is the queen of mathematics." Demonstrating exceptional mathematical insight, Gauss, at the young age of 24, made a seminal contribution to the field in 1801 with the publication of his magnum opus, "Disquisitiones Arithmeticae." Widely regarded as the most influential work in the field of number theory, "Disquisitiones Arithmeticae" stands as a testament to Gauss's unparalleled intellect. In this groundbreaking book, he delved into intricate mathematical concepts, providing profound insights and establishing foundational principles that would shape the course of number theory for generations to come. Gauss's enduring impact on the field is not only evident in the elegance of his mathematical formulations but also in his ability to elevate number theory to a position of paramount importance within the broader scientific landscape.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss revolutionized number theory through the introduction of the concept of congruence, a method of establishing agreement between numbers. Central to this innovation was the utilization of "modulos" or defined sets of numbers, allowing for the subdivision of the infinite series of whole numbers into more manageable segments. This ingenious theory of congruence enabled the simplification of computations by breaking down complex arithmetic tasks, making them more amenable to programming in computer systems. According to Gauss's proposition, when one number is subtracted from another (a - b), if the remainder of this subtraction is divisible by another number, denoted as m, then a and b are considered congruent to each other modulo m. Gauss articulated this relationship with the concise formula: a is congruent to b modulo c. As an illustration, consider the subtraction 720 - 480, resulting in a remainder of 240. This remainder is divisible by 60, 20, 10, and other numbers, but for the sake 
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;of illustration, let's focus on 60. Applying Gauss's expression, we can assert that 720 is congruent to 480 modulo 60. In essence, both 720 and 480 share a mathematical connection through a third number (the remainder after subtracting 480 from 720), which can be expressed as a multiple of 60. This elegant concept not only enhances computational efficiency but also finds practical application in diverse areas, such as timekeeping algorithms in computer programming. In a conceptual sense, this mathematical process finds practical application in everyday tasks such as interpreting the time displayed on a digital watch. Instead of stating "240 minutes past noon," the digital watch simplifies the information to "4 o'clock" or "4:00." This temporal representation involves the use of various modulos, or defined measures, which have been employed for centuries. For instance, there are 60 minutes in an hour and 12 hours in the a.m. or p.m. of a day. Consider the scenario where a digital watch indicates 4:00 in the afternoon. From a particular perspective, this translates to subtracting 480 minutes from the 720-minute period between 12 noon and midnight. The result is 240 minutes past noon (720 - 480 = 240). This remaining time, 240 minutes, aligns evenly with the modulo 60 (as well as other numbers we will overlook), illustrating the seamless integration of Gauss's modular arithmetic principles into the practical functionality of digital timekeeping.


        </p>
    </div>  


    <div class="introduction chap6">
        <p id="title">Chapter 6: Conclusion</p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss showed a great capacity for mental calculations from an early age. Due to his mathematical capabilities, Gauss mostly worked on his inventions on his own. He had a very complicated and hard childhood. Gauss taught himself how to read. His teachers were very astonished by what Gauss was able to accomplish at a very young age. Despite this, Gauss’s father was strict in ensuring that Gauss focused on his studies.
            `
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To add to that, politics played a huge part in his life. Gauss's first mentor was his elementary school teacher, Herr Büttner. Herr Büttner recognized Gauss's exceptional mathematical abilities at an early age. Gauss's remarkable talent is demonstrated by the well-known account of him summing the numbers from 1 to 100 while still in elementary school. Admiring Gauss's resourcefulness, Herr Büttner resolved to develop the young prodigy's abilities. He gave Gauss books on advanced mathematics and pushed him to solve difficult problems that went way beyond the syllabus. Gauss's love for mathematics and his aptitude for mathematics were greatly influenced by Herr Büttner's mentoring. With his knowledge, a lot of people tried to exploit Gauss so his father and Gauss’s mentor supplied him with books to motivate him to study and develop himself more.


        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gauss craved greater intellectual challenges as his studies advanced. Around this time, he met Professor Wolfgang Bolyai, a well-known mathematician at the University of Helmstedt, who would become his second mentor. Gauss was mentored by Professor Bolyai, who saw his promise. Gauss showed his natural mathematical capabilities by discovering a straightforward formula that allowed him to compute the sum quickly while other kids found it difficult to complete this very difficult task. In the year 1788, Gauss began studying at Gymnasium, a secondary school located in Germany where he continued to excel in mathematics and displayed an immense need for knowledge. His education, however, was not limited to mathematics. He also studied Latin, Greek, and other subjects that other students take in school, which would later prove to be very advantageous in his mathematical work. Gauss maintained his mathematical ability while he was a student at the Carolinum Gymnasium. He was lucky to have J.G. as a math teacher. Bartels, who appreciated his special abilities and supported his academic endeavors. Bartels was a key figure in Gauss's development, helping him with his studies and exposing him to works on advanced mathematics. Gauss started to formulate his own mathematical theories and make novel contributions to the area while being mentored by Bartels. At the age of 14, he was given an allowance from the duke which allowed him to focus his attention in his studies. There, he discovered the binomial theorem and the law of quadratic reciprocity.
        </p>

        <p id="subcontent">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From a young age, Carl Friedrich Gauss made substantial contributions to the field of mathematics, and his impact could be seen in both academic and practical contexts. His works, from an early age played a significant part in our fundamental understandings of the world. For example, at the age of 15, Gauss found a formula to find the sum of the first natural numbers and even found a way to find the product of these numbers. Furthermore, he also developed a way to figure out if a given number is a prime number. He started to add to the mathematical knowledge of his era after absorbing it. At the age of 19, he achieved a great feat in building the heptadecagon, a 17-sided polygon, which pioneered his future mathematical breakthroughs. In the field of statistics, Gauss developed the least squares method. This allowed individuals to minimize the sum of squares between the observed and calculated values.

        </p>
    </div>


</main>
   

    
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>


<script>

    $(document).ready(function(){  
        $('.mainParent').addClass('revealme');
     
       
        $(".highlighter").click(function(){
            $(".i").toggleClass("blue");
            console.log("gumana");
        });

  var isMoonClicked = false;
 

$('.moon').click(function () {
    isMoonClicked = !isMoonClicked; // Toggle the click state
  if (isMoonClicked) {


    $("#topBar").toggleClass("topBar");
            $("#topBar").toggleClass("topBar-dark");

            $("nav").toggleClass("nav");
            $("nav").toggleClass("nav-dark");

            $("#home").toggleClass("home-white");
            $("#home").toggleClass("home-dark");

            $(".mainParent").toggleClass("black");




    console.log('Moon is clicked');
  } else {

  

    $("#topBar").toggleClass("topBar");
            $("#topBar").toggleClass("topBar-dark");

            $("nav").toggleClass("nav");
            $("nav").toggleClass("nav-dark");

            $("#home").toggleClass("home-white");
            $("#home").toggleClass("home-dark");

            $(".mainParent").toggleClass("black");

            $(".highlighter").click(function(){
            $(".i").toggleClass("blue");
        });


    console.log('Moon is not clicked');
    // Perform actions when the moon is not clicked
  }


  //$('.highlighter').click(function () {
  //if(isMoonClicked){
  //$(".i").toggleClass("blue");
  //console.log("Moon is clicked")
    
  //}

  //else{
  //$(".i").toggleClass("yellow");
  //console.log("Moon is not clicked")
  //}

  //   });




});




        
    

    });






</script>


<script>


$(document).ready(function(){

    
    $(".mathDropdown").hide();

    $(".navDropdown").hide();

  

  $("#subtopic").click(function(){
    $(".navDropdown").fadeToggle("fast");
    $(this).toggleClass('subtopicclass');
  });


  $("#chap4").click(function(){
    $(".mathDropdown").fadeToggle("fast");
    var currentColor = $(this).css("color");

    // Toggle between default color and orange
    var newColor = (currentColor === "rgb(255, 165, 0)") ? "" : "orange";
    
    // Apply the new color
    $(this).css("color", newColor);

  });

  $("#bars").click(function(){
    var nav = $("nav");

if (nav.hasClass("navshow")) {
    nav.removeClass("navshow");
} else {
    nav.addClass("navshow");
}

  });


  


  function checkWidth() {
    var element = $('nav');
    if ($(window).width() < 670) {
      element.addClass('navhide');   

      $(".mainParent").click(function(){
        $("nav").removeClass('navshow');
        console.log("pogi");
    })
      
      
  

    } else {
      
        console.log("fck u");


    }
  }

  // Initial check when the page loads
  checkWidth();

  // Add event listener for window resize
  $(window).resize(checkWidth);


  $('#chap1').click(function() {
    $('.introduction').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap2').click(function() {
    $('.chap2').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap3').click(function() {
    $('.chap3').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap4-1').click(function() {
    $('.chap4-1').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap4-2').click(function() {
    $('.chap4-2').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap5').click(function() {
    $('.chap5').get(0).scrollIntoView({ behavior: 'smooth' });
  });

  $('#chap6').click(function() {
    $('.chap6').get(0).scrollIntoView({ behavior: 'smooth' });
  });

});

</script>




</html>

});

</script>




</html>