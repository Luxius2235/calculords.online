<?php
	include ('auth/conn.php');
	session_start();
		
	if (isset($_POST['like'])){		
		
		$id = $_POST['id'];
		$query=mysqli_query($con,"select * from `likes` where commid='$id' and userid='".$_SESSION['id']."' ");
		date_default_timezone_set('Asia/Manila');
		$date = date('y-m-d H:i:s');

		if(mysqli_num_rows($query)>0){
			mysqli_query($con,"delete from `likes` where userid='".$_SESSION['id']."' and commid='$id'");
			

		}
		else{
			mysqli_query($con,"insert into `likes` (userid,commid,liketime) values ('".$_SESSION['id']."', '$id', '$date')");
			
		}
	}		
?>


