<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/top-nav-dark.css" rel="stylesheet">
    <link href="style/members.css" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="images/favicon/icon1.svg">
    <script src="https://kit.fontawesome.com/63844d2341.js" crossorigin="anonymous"></script>
    <title>Gauss | Home</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    } 
    
    @media screen and (max-width:1200px) {
    

    .membersParent{
        max-width: 13rem;
        margin: auto;
        margin-top: 1rem;
        margin-bottom:1rem;
        margin-left:3rem;
    }

    .motto{
        font-size: x-small;
        width: 7rem;
        margin: auto;
        margin-top: 0.5rem;
        
        color: rgba(255, 255, 255, 0.567);
    }

    .name{
        max-width: 9rem;
    }
}
   


    
 @media screen and (max-width:400px) {
    .membersParent>img{
        height: 6rem;
        width: 6rem;
    }
    

    .membersParent{
        max-width: 13rem;
        margin: auto;
        margin-top: 1rem;
        margin-bottom:1rem;
        margin-left:0rem;
    }

    .motto{
        font-size: x-small;
        width: 7rem;
        margin: auto;
        margin-top: 0.5rem;
        
        color: rgba(255, 255, 255, 0.567);
    }

    .name{
        max-width: 9rem;
    }
}
    
    </style>

    </head>
    <body>

<div class="topBar">
    <i id="webName"> C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></i> 
    <section class="barsclass">
        <i id="bars" class="fa-solid fa-bars"></i>
    </section>
    
  </div>

    <nav>

       <ul>
        <li id="home" onclick="location.href='index.php'"><i class="fa-solid fa-house fa-xl" ></i> Home</li>
        <li onclick="location.href='video.php'"><i class="fa-solid fa-video fa-xl" ></i> Video</li>
        <li onclick="location.href='comment.php'"><i class="fa-solid fa-comment fa-xl" ></i> Comment</li>
        <li id="members" onclick="location.href='members.php'"><i class="fa-solid fa-person fa-xl"> </i> About us</li>
        <li onclick="location.href='references.php'"><i class="fa-brands fa-sourcetree fa-xl" ></i> References</li>
        
        <?php
        if(!isset($_SESSION['loggedin'])){}
        else{
        ?> 


        <li onclick="location.href='auth/logout.php'"><i class="fa-solid fa-right-from-bracket fa-xl"></i> Log out</li>

        <?php
        }

?>
       </ul>






        
    </nav>


    <main class="mainParent" >
        <span class="damembers">The Members</span>
      <div class="membersMainParent">
        <section class="membersParent">
          <img src="Images/alfea.jpeg" alt="">
          <span class="name">Alfea Jenica B. Aguilar</span>
          <span class="motto">Luluhod sa munggo, wag lamang ma kwatro.Luluhod sa munggo, wag lamang ma kwatro.</span>
        </section>
        <section class="membersParent">
          <img src="Images/sean.jpg" alt="">
          <span class="name">Sean Chelsea E. Balmaceda</span>
          <span class="motto">“If you’re going to LIMIT your dreams, at least tend them to INFINITY.”</span>
        </section>
        <section class="membersParent">
          <img src="Images/carp.jpg" alt="">
          <span class="name">Jovelyn M. Carpentero</span>
          <span class="motto">"Mathematics is not about numbers, equations, computations, or algorithms: it is about understanding."<br>— William Paul Thurston</span>
        </section>
        <section class="membersParent">
          <img src="Images/danica.jpg" alt="">
          <span class="name">Danica Joy DC. Delos Santos</span>
          <span class="motto">“Mathematics consists of proving the most obvious thing in the least obvious way.” <br>— George Polya</span>
        </section> 

        <section class="membersParent">
          <img src="Images/nator.png" alt="">
          <span class="name">Marj Nathan E. Nator</span>
          <span class="motto">Luluhod sa munggo, wag lamang ma kwatro.</span>
        </section>
        <section class="membersParent">
          <img src="Images/andrei.JPG" alt="">
          <span class="name">Andrei C. Pia </span>
          <span class="motto">"Luluhod sa munggo, wag lamang ma kwatro."</span>
        </section>
        <section class="membersParent">
          <img src="Images/santigao.jpg" alt="">
          <span class="name">Ma. Angelie T. Santiag</span>
          <span class="motto">"In the world of calculus, problems are not obstacles; they are opportunities to unravel the mysteries of numbers and uncover the elegance of mathematical design."<br>- Leonhard Euler</span>
        </section>
     
      </div>
    </main>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>


$(document).ready(function(){

  $('.membersParent').addClass('reveal');
  $('.damembers').addClass('bulaga');

    
    $(".mathDropdown").hide();

    $(".navDropdown").hide();

  $("#subtopic").click(function(){
    $(".navDropdown").fadeToggle("fast");
    $(this).toggleClass('subtopicclass');
  });


  $("#chap4").click(function(){
    $(".mathDropdown").fadeToggle("fast");
    var currentColor = $(this).css("color");

    // Toggle between default color and orange
    var newColor = (currentColor === "rgb(255, 165, 0)") ? "" : "orange";
    
    // Apply the new color
    $(this).css("color", newColor);

  });

  $("#bars").click(function(){
    var nav = $("nav");

if (nav.hasClass("navshow")) {
    nav.removeClass("navshow");
} else {
    nav.addClass("navshow");
}

  });


  


  function checkWidth() {
    var element = $('nav');
    if ($(window).width() < 670) {
      element.addClass('navhide');   

      $(".mainParent").click(function(){
        $("nav").removeClass('navshow');
        console.log("pogi");
    })
      
      
  

    } else {
      
        console.log("fck u");


    }
  }

  // Initial check when the page loads
  checkWidth();

  // Add event listener for window resize
  $(window).resize(checkWidth);
});
</script>

<script>
    const observer = new IntersectionObserver((enteries) => {enteries.forEach((entry) => {
    console.log(entry)
        if (entry.isIntersecting) {
    entry.target.classList.add('show');
    } else { 
    entry.target.classList.remove('show');
    }
    });
    });
    
    const hiddenElements = document.querySelectorAll('.left');
    hiddenElements.forEach((el) => observer.observe(el));
    
    const hiddenElementss = document.querySelectorAll('.right');
    hiddenElementss.forEach((el) => observer.observe(el));
    </script>


</html>