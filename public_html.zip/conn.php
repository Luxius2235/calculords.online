<?php

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'u229967681_lords';
$DATABASE_PASS = 'Andreipogipia22';
$DATABASE_NAME = 'u229967681_lords';
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

include_once "time.php";
if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}