<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/top-nav-dark.css" rel="stylesheet">
    <link href="style/references.css" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="images/favicon/icon1.svg">
    <script src="https://kit.fontawesome.com/63844d2341.js" crossorigin="anonymous"></script>
    <title>Gauss | Home</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    } 

    
    </style>
    </head>
<body>
    
<div class="topBar">
    <i id="webName"> C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></i> 
    <section class="barsclass">
        <i id="bars" class="fa-solid fa-bars"></i>
    </section>
    
</div>

    <nav>

       <ul>
        <li id="home" onclick="location.href='index.php'"><i class="fa-solid fa-house fa-xl" ></i> Home</li>
        <li onclick="location.href='video.php'"><i class="fa-solid fa-video fa-xl" ></i> Video</li>
        <li onclick="location.href='comment.php'"><i class="fa-solid fa-comment fa-xl" ></i> Comment</li>
        <li  onclick="location.href='members.php'"><i class="fa-solid fa-person fa-xl"> </i> About us</li>
        <li onclick="location.href='references.php'" id="members"><i class="fa-brands fa-sourcetree fa-xl" ></i> References</li>
        
        <?php
        if(!isset($_SESSION['loggedin'])){}
        else{
        ?> 


        <li onclick="location.href='auth/logout.php'"><i class="fa-solid fa-right-from-bracket fa-xl"></i> Log out</li>

        <?php
        }

?>
       </ul>






        
    </nav>


    <main class="mainParent">
        <span class="ref">The References</span>
        <p class="referenceP">
            Birch, D. (n.d.). Gaussian gravitational constant. Oxford Reference. <a href="https://www.oxfordreference.com/display/10.1093/oi/authority.20110803095844968">https://www.oxfordreference.com/display/10.1093/oi/authority.20110803095844968</a><br>

            Bhatia, A. (2014, September 5). How a 19th Century Math Genius Taught Us the Best Way to Hold a Pizza Slice. WIRED. <a href="https://www.wired.com/2014/09/curvature-and-strength-empzeal/">https://www.wired.com/2014/09/curvature-and-strength-empzeal/</a><br>
            
            Carl Friedrich Gauss (2016, August 24). Encyclopedia.com. <a href="https://www.encyclopedia.com/people/science-and-technology/mathematics-biographies/carl-friedrich-gauss">https://www.encyclopedia.com/people/science-and-technology/mathematics-biographies/carl-friedrich-gauss</a><br>
            
            Carl Friedrich Gauss – Biography, Facts and Pictures. (2018, August 15). Famous Scientists. <a href="https://www.famousscientists.org/carl-friedrich-gauss/">https://www.famousscientists.org/carl-friedrich-gauss/</a><br>
            
            Carl Friedrich Gauss. (n.d.). Maths History. <a href="https://mathshistory.st-andrews.ac.uk/Biographies/Gauss/">https://mathshistory.st-andrews.ac.uk/Biographies/Gauss/</a><br>
            
            Carl Friedrich Gauss’ Contributions in Mathematics. (n.d.). Studious Guy. <a href="https://studiousguy.com/carl-friedrich-gauss-contributions-in-mathematics/#5_Number_Theory">https://studiousguy.com/carl-friedrich-gauss-contributions-in-mathematics/#5_Number_Theory</a><br>
            
            Dunnington, W. (May, 1927). The Sesquicentennial of the Birth of Gauss. The Scientific Monthly, 24(5), 402–414. <a href="http://www.jstor.org/stable/7912">http://www.jstor.org/stable/7912</a><br>
            
            Gauss and constuctable polygons. (n.d.). <a href="https://pballew.blogspot.com/2011/03/gauss-and-constuctable-polygons.html">https://pballew.blogspot.com/2011/03/gauss-and-constuctable-polygons.html</a><br>
            
            Gauss, Carl Friedrich: Disquisitiones generales circa superficies curvas, in: Noscemus Wiki, URL: <a href="http://wiki.uibk.ac.at/noscemus/Disquisitiones_generales_circa_superficies_curvas">http://wiki.uibk.ac.at/noscemus/Disquisitiones_generales_circa_superficies_curvas</a><br>
            
            Gauss, Carl Friedrich. (n.d.). Larson Calculus. <a href="https://www.larsoncalculus.com/calc10/content/biographies/gauss-carl-friedrich/">https://www.larsoncalculus.com/calc10/content/biographies/gauss-carl-friedrich/</a><br>
            
            Gauss, Karl Friedrich (1777-1855). (n.d.). Wolfram Research. <a href="http://scienceworld.wolfram.com/biography/Gauss.html">http://scienceworld.wolfram.com/biography/Gauss.html</a><br>
            
            Gray, J. J. (2023, October 20). Carl Friedrich Gauss | Biography, Discoveries, & Facts. Encyclopedia Britannica. <a href="https://www.britannica.com/biography/Carl-Friedrich-Gauss">https://www.britannica.com/biography/Carl-Friedrich-Gauss</a><br>
            
            Johann Karl Friedrich Gauss. (2018, November 22). Department of Mathematics. <a href="https://sci.umanitoba.ca/mathematics/resources/gauss/">https://sci.umanitoba.ca/mathematics/resources/gauss/</a><br>
            
            Johann Carl Friedrich Gauss. (n.d.). Magcraft. <a href="https://www.magcraft.com/johann-carl-friedrich-gauss#:~:text=Gauss%20was%20born%20in%20Brunswick,mathematical%20solutions%20in%20his%20head.">https://www.magcraft.com/johann-carl-friedrich-gauss#:~:text=Gauss%20was%20born%20in%20Brunswick,mathematical%20solutions%20in%20his%20head.</a><br>
            
            Johann Carl Friedrich Gauss. (n.d.). New World Encyclopedia. <a href="https://www.newworldencyclopedia.org/entry/Johann_Carl_Friedrich_Gauss#Early_years">https://www.newworldencyclopedia.org/entry/Johann_Carl_Friedrich_Gauss#Early_years</a><br>
            
            Knill, O. (2011). Divergence theorem. Harvard Math. <a href="https://people.math.harvard.edu/~knill/teaching/summer2011/handouts/64-divergence.pdf">https://people.math.harvard.edu/~knill/teaching/summer2011/handouts/64-divergence.pdf</a><br>
            
            Lim, M. (2021, March 31). Gauss, Least Squares, and The Missing Planet. Actuaries Digital. <a href="https://www.actuaries.digital/2021/03/31/gauss-least-squares-and-the-missing-planet/">https://www.actuaries.digital/2021/03/31/gauss-least-squares-and-the-missing-planet/</a><br>
            
            Macelr, L. (n.d.). Asteroid orbit determination project. <a href="http://www.columbia.edu/~my2317/asteroidproject.html">http://www.columbia.edu/~my2317/asteroidproject.html</a><br>
            
            Müller, G. (n.d.). 28. Lenz’s rule. applications of Faraday’s law - digitalcommons.uri.edu. <a href="https://digitalcommons.uri.edu/cgi/viewcontent.cgi?article=1027&context=phy204-lecturenotes">https://digitalcommons.uri.edu/cgi/viewcontent.cgi?article=1027&context=phy204-lecturenotes</a><br>
            
            Numerical Integration: Gauss Quadrature. (n.d.). Engineering at Alberta. <a href="https://engcourses-uofa.ca/books/numericalanalysis/numerical-integration/gauss-quadrature/">https://engcourses-uofa.ca/books/numericalanalysis/numerical-integration/gauss-quadrature/</a><br>
            
            Number Theory - Gauss And Congruence. (n.d.). <a href="https://science.jrank.org/pages/4772/Number-Theory-Gauss-congruence.html">https://science.jrank.org/pages/4772/Number-Theory-Gauss-congruence.html</a><br>
            
            Number theory | Definition, Topics, & History. (2023, October 6). Encyclopedia Britannica. <a href="https://www.britannica.com/science/number-theory/Pierre-de-Fermat">https://www.britannica.com/science/number-theory/Pierre-de-Fermat</a><br>
            
            Plackett, R. L. (1972). Studies in the History of Probability and Statistics. XXIX: The Discovery of the Method of Least Squares. Biometrika, 59(2), 239–251. <a href="https://doi.org/10.2307/2334569">https://doi.org/10.2307/2334569</a><br>
            
            Regular polygon - Conservapedia. (n.d.). <a href="https://www.conservapedia.com/Regular_polygon">https://www.conservapedia.com/Regular_polygon</a><br>
            
            Ryu, E. K., & Boyd, S. P. (2014). Extensions of Gauss Quadrature Via Linear Programming. Foundations of Computational Mathematics. <a href="https://doi.org/10.1007/s10208-014-9197-9">https://doi.org/10.1007/s10208-014-9197-9</a><br>
            
            Salamin, E. (1976). Computation of $\pi$ Using Arithmetic-Geometric Mean. Mathematics of Computation, 30(135), 565–570. <a href="https://doi.org/10.2307/2005327">https://doi.org/10.2307/2005327</a><br>
            
            Snyder, J. P. (1994, January 1). Map Projections: A Working Manual. Professional Paper. <a href="https://pubs.usgs.gov/publication/pp1395">https://pubs.usgs.gov/publication/pp1395</a><br>
            
            Sprott, D. A. (1978). Gauss’s contributions to statistics. Historia Mathematica, 5(2), 183–203. <a href="https://doi.org/10.1016/0315-0860(78)90049-6">https://doi.org/10.1016/0315-0860(78)90049-6</a><br>
            
            Stahl, S. (2006). The Evolution of the Normal Distribution. Mathematics Magazine, 79(2), 96–113. <a href="https://doi.org/10.2307/27642916">https://doi.org/10.2307/27642916</a><br>
            
            Stigler, S. M. (1981). Gauss and the Invention of Least Squares. The Annals of Statistics, 9(3), 465–474. <a href="http://www.jstor.org/stable/2240811">http://www.jstor.org/stable/2240811</a><br>
            
            Stokes Theorem: Gauss Divergence Theorem, Definition and Proof. (2020, May 15). Toppr-guides. <a href="https://www.toppr.com/guides/maths/stokes-theorem">https://www.toppr.com/guides/maths/stokes-theorem</a><br>
            
            Talsayu, J. (n.d.). Gaussian units. Gaussian units - Knowino. <a href="https://www.theochem.ru.nl/~pwormer/Knowino/knowino.org/wiki/Gaussian_units.html">https://www.theochem.ru.nl/~pwormer/Knowino/knowino.org/wiki/Gaussian_units.html</a><br>
            
            The Editors of Encyclopedia Britannica. (1998, July 20). Normal distribution | Definition, Examples, Graph, & Facts. Encyclopedia Britannica. <a href="https://www.britannica.com/topic/normal-distribution">https://www.britannica.com/topic/normal-distribution</a><br>
            
            Weiss, L. (n.d.). Gauss and Ceres. <a href="https://sites.math.rutgers.edu/~cherlin/History/Papers1999/weiss.html">https://sites.math.rutgers.edu/~cherlin/History/Papers1999/weiss.html</a><br>
            
            Zormbala, K. (1996). Gauss and the definition of the plane concept in Euclidean Elementary Geometry. Historia Mathematica, 23(4), 418–436. <a href="https://doi.org/10.1006/hmat.1996.0040">https://doi.org/10.1006/hmat.1996.0040</a><br>
            
            
            </p>
    </main>






</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>


$(document).ready(function(){
    $(".ref").addClass('bulaga')
    $(".referenceP").addClass('p')
    
    $(".mathDropdown").hide();

    $(".navDropdown").hide();

  $("#subtopic").click(function(){
    $(".navDropdown").fadeToggle("fast");
    $(this).toggleClass('subtopicclass');
  });


  $("#chap4").click(function(){
    $(".mathDropdown").fadeToggle("fast");
    var currentColor = $(this).css("color");

    // Toggle between default color and orange
    var newColor = (currentColor === "rgb(255, 165, 0)") ? "" : "orange";
    
    // Apply the new color
    $(this).css("color", newColor);

  });

  $("#bars").click(function(){
    var nav = $("nav");

if (nav.hasClass("navshow")) {
    nav.removeClass("navshow");
} else {
    nav.addClass("navshow");
}

  });


  


  function checkWidth() {
    var element = $('nav');
    if ($(window).width() < 670) {
      element.addClass('navhide');   

      $(".mainParent").click(function(){
        $("nav").removeClass('navshow');
        console.log("pogi");
    })
      
      
  

    } else {
      
        console.log("fck u");


    }
  }

  // Initial check when the page loads
  checkWidth();

  // Add event listener for window resize
  $(window).resize(checkWidth);
});

</script>


</html>