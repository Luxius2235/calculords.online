
<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/top-nav-dark.css" rel="stylesheet">
    <link href="style/references.css" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="images/favicon/icon1.svg">
    <script src="https://kit.fontawesome.com/63844d2341.js" crossorigin="anonymous"></script>
    <title>Gauss | Home</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    } 

    
    </style>
    </head>
<body>
    
<div class="topBar">
    <i id="webName"> C A L C U L O R D S&nbsp;&nbsp;<i class="fa-solid fa-square-root-variable"></i></i> 
    <section class="barsclass">
        <i id="bars" class="fa-solid fa-bars"></i>
    </section>
    
</div>

    <nav>

       <ul>
        <li id="home" onclick="location.href='index.php'"><i class="fa-solid fa-house fa-xl" ></i> Home</li>
        <li onclick="location.href='video.php'" id="members"><i class="fa-solid fa-video fa-xl" ></i> Video</li>
        <li onclick="location.href='comment.php'"><i class="fa-solid fa-comment fa-xl" ></i> Comment</li>
        <li  onclick="location.href='members.php'"><i class="fa-solid fa-person fa-xl"> </i> About us</li>
        <li onclick="location.href='references.php'" ><i class="fa-brands fa-sourcetree fa-xl" ></i> References</li>
        
        <?php
        if(!isset($_SESSION['loggedin'])){}
        else{
        ?> 


        <li onclick="location.href='auth/logout.php'"><i class="fa-solid fa-right-from-bracket fa-xl"></i> Log out</li>

        <?php
        }

?>
       </ul>






        
    </nav>


    <main class="mainParent" style="padding-top:5rem; border:none;">
        <span class="ref">We dont have our video pa, thank you.</span>
     
    </main>






</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>


$(document).ready(function(){
    $(".ref").addClass('bulaga')
    $(".referenceP").addClass('p')
    
    $(".mathDropdown").hide();

    $(".navDropdown").hide();

  $("#subtopic").click(function(){
    $(".navDropdown").fadeToggle("fast");
    $(this).toggleClass('subtopicclass');
  });


  $("#chap4").click(function(){
    $(".mathDropdown").fadeToggle("fast");
    var currentColor = $(this).css("color");

    // Toggle between default color and orange
    var newColor = (currentColor === "rgb(255, 165, 0)") ? "" : "orange";
    
    // Apply the new color
    $(this).css("color", newColor);

  });

  $("#bars").click(function(){
    var nav = $("nav");

if (nav.hasClass("navshow")) {
    nav.removeClass("navshow");
} else {
    nav.addClass("navshow");
}

  });


  


  function checkWidth() {
    var element = $('nav');
    if ($(window).width() < 670) {
      element.addClass('navhide');   

      $(".mainParent").click(function(){
        $("nav").removeClass('navshow');
        console.log("pogi");
    })
      
      
  

    } else {
      
        console.log("fck u");


    }
  }

  // Initial check when the page loads
  checkWidth();

  // Add event listener for window resize
  $(window).resize(checkWidth);
});

</script>


</html>