<?php

include 'conn.php';
$error="";

if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
};
//pag kulang ung sinubmit na data
if (!isset($_POST['firstName'], $_POST['lastName'],$_POST['email'], $_POST['pass'], $_POST['username'])) {
    echo "<span class='Error'>Fill in all fields.</span>";
};
//pag walang laman ang input
if (empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['gender']) || empty($_POST['section']) || empty($_POST['email']) || empty($_POST['pass']) || empty($_POST['username'])) {
    echo "<span class='Error'>Fill in all fields.</span>";
    exit();
};

if (strlen($_POST['pass']) < 10) {
    echo "<span class='Error'>Password is too short.</span>";
    exit();
}

if (strlen($_POST['username']) > 10) {
    echo "<span class='Error'>Username is too long</span>";
    exit();
}

$username = $_POST['username'];
$usernameNew = preg_replace("/\s+/", "",$username);


if ($stmt = $con->prepare('SELECT id, pass FROM users WHERE username = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
	$stmt->bind_param('s', $usernameNew);
	$stmt->execute();
	$stmt->store_result();
    if ($stmt->num_rows > 0) {
		// Username already exists
        echo "<span class='Error'>Username already exist.</span>";
        exit();
	}


}



if ($stmt = $con->prepare('SELECT id, pass FROM users WHERE email = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
	$stmt->bind_param('s', $_POST['email']);
	$stmt->execute();
	$stmt->store_result();
	// Store the result so we can check if the account exists in the database.
	if ($stmt->num_rows > 0) {
		// Username already exists
		$_SESSION["error"] = $exist;
        echo "<span class='Error'>Email already exist.</span>";
        exit();



	} else {

        $role = 'user';
        $prof = 'gauss.jpg';
        
		if ($stmt = $con ->prepare('INSERT INTO users (firstName, lastName, email, pass, username, role, prof) VALUES (?, ?, ?, ?, ?)')){
            $pass = password_hash($_POST['pass'], PASSWORD_DEFAULT);
            $stmt -> bind_param ('sssssss', $_POST['firstName'], $_POST['lastName'], $_POST['email'],$pass, $usernameNew, $role, $prof);
            $stmt -> execute();

            


        }

        else{

        }
    
    }
    
    
    
    
    
    
    
        $stmt -> close();    
    }
        else {
            echo "<span class='Error'>Register Failed.</span>";
        }   
                $con -> close();
                ?>
