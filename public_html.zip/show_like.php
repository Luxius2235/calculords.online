<?php
	session_start();
	include('auth/conn.php');
	
	if (isset($_POST['showlike'])){
		$id = $_POST['id'];
		$query2=mysqli_query($con,"SELECT * FROM `likes` WHERE commid='$id'");
		echo mysqli_num_rows($query2);	
	}
?>

