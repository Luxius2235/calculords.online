<?php
session_start();

include'auth/conn.php';
include'auth/session.php';

?>



<?php
  $commentnewcount = $_POST['commentnewcount'];
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof, usr.id  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC LIMIT $commentnewcount";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){

    $ids = $row['id'];
?>
  <div class="user-comment-parent">

    <div class="user-comment-cont">
      <img src="Images/<?=$row['prof']?>" alt="Profile">
      <section class="nametime-cont">
        <i><?=$row['username']?></i>
        <i id="time"><?=getDateTimeDiff($row['time']);?></i>
      </section>


     
      <div class="pin-trash"> 
      <?php
if($_SESSION['role'] === 'developer') {
?>
        <i class="fa-solid fa-thumbtack pin pin<?=$row['commid']?>"></i>
        <?php
}else {}
        ?>
        
        
<?php
if($_SESSION['role'] === 'developer' or $_SESSION['id'] == $row['userid']) {
?>
        <i class="fa-solid fa-trash ellipsis thrash<?=$row['commid']?>"></i>

        <?php
}else {}
        ?>
      </div>
    
     
    </div>
  
    <div>
      <section class="user-comment">
        <p><?=$row['comment']?></p>
      </section>
      <ul class="react-cont">

      <?php
                    
      $query1=mysqli_query($con,"select * from `likes` where commid='".$row['commid']."' and userid='".$_SESSION['id']."'");
      if (mysqli_num_rows($query1)>0){                           
    ?>      
<button class="unlike" id="heart" value="<?php echo $row['commid'];?>">
<i class="fa-solid fa-greater-than fa-xl" style="color: orange;"></i>      
    <?php
    }
    else{
    ?>
<button class="like" id="heart" value="<?php echo $row['commid']; ?>">
<i class="fa-solid fa-greater-than fa-xl" style="color: gray;"></i> 

      <?php
           }
      ?>

      </button>
        <a class="span" id="show_like<?php echo $row['commid']; ?>" style="font-size: x-small;">
      
        <?php
                        $query3=mysqli_query($con,"select * from `likes` where commid='".$row['commid']."'");
                        echo mysqli_num_rows($query3);
                    ?>

      </a> 
    
    </li>




      </ul>
    </div>

    
  
  </div>

  <?php
   };

?>




<script> 
  
<?php
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){
?>

    


    $(".pin<?=$row['commid']?>").click(function(){
      console.log('<?=$row['commid']?>')
    var userChoice = confirm("Are you sure you want pin this comment?");
    if (userChoice) {
      commid = <?=$row['commid']?>;
      $.ajax({
                url: 'auth/pin.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
                  
                  
                }
            });
    } else {

    }
    });

    <?php
   };

?>





  
  </script>

<script>

<?php
   $sql = "SELECT comm.userid, comm.comment, comm.time, comm.commid, usr.first, usr.last, usr.username, usr.role, usr.prof  FROM comments comm, users usr WHERE comm.userid = usr.id ORDER BY comm.commid DESC";
   $result =  mysqli_query($con, $sql);
   while ($row = mysqli_fetch_assoc($result)){
?>

    $(".thrash<?=$row['commid']?>").click(function(){
   
    var userChoice = confirm("Are you sure you want to delete this?");
    if (userChoice) {
    
      commid = <?=$row['commid']?>;
      $.ajax({
                url: 'auth/deletecomm.php',
                type: 'POST',
                data: { commid: commid },
                success: function(response) {
               
                }
            });

            console.log('pogiako');
    } else {

    }
    });

    <?php

   };

?>
  </script>

